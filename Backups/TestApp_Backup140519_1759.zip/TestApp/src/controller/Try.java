package controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAOPackage.*;
import JavaBeans.*;
/**
 * Servlet implementation class Try
 */
@WebServlet("/Try")
public class Try extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Try() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username, password, name, surname, address, city, cap, nation, phone, email;
		boolean isAdmin,canAccess;
		
		username=request.getParameter("usr");
		password=request.getParameter("password");
		name=request.getParameter("name");
		surname=request.getParameter("surname");
		address=request.getParameter("address");
		city=request.getParameter("city");
		cap=request.getParameter("cap");
		nation=request.getParameter("nation");
		phone=request.getParameter("phone");
		email=request.getParameter("email");
		isAdmin=false;
		canAccess=true;
		
		UserBean usrBean=new UserBean();
		usrBean.setUsername(username);
		usrBean.setPassword(password);
		usrBean.setName(name);
		usrBean.setSurname(surname);
		usrBean.setAddress(address);
		usrBean.setCity(city);
		usrBean.setCap(cap);
		usrBean.setNation(nation);
		usrBean.setPhone(phone);
		usrBean.setEmail(email);
		usrBean.setAdmin(isAdmin);
		usrBean.setCanAccess(canAccess);
		
		UserDAO user=new UserDAO();
		/*
		try {
			user.doSaveOrUpdate(usrBean);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		try {
			user.doDelete(usrBean);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.sendRedirect("index.html");
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
